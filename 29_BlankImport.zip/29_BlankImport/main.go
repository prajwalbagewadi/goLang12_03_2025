package main

import (
	"fmt"
	_ "modA"
)

func main() {
	fmt.Print("Hello, World!")
}