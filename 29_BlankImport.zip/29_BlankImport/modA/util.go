package modA

import (
	"fmt"
)

func init() {
	fmt.Println("BlankImport package initialized")
}